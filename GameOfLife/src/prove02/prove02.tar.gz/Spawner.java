package prove02;

public interface Spawner
{
    //Create a new Creature from existing one
    public Creature spawnNewCreature();
}
